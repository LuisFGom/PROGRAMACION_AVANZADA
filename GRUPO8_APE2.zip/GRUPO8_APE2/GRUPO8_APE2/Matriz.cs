﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRUPO8_APE2
{
    public partial class Matriz : Form
    {
        public Matriz()
        {
            InitializeComponent();
            InitializeControls();
        }

        private void InitializeControls()
        {
            dataGridView2.ReadOnly = true;
            btnCrear.Click += BtnCrear_Click;
        }

        // Nuevo evento del botón para generar la matriz
        private void BtnCrear_Click(object sender, EventArgs e)
        {
            SetupDataGridView(dataGridView1);
            SetupDataGridView(dataGridView2);
        }

        private void ConfigurarGrid(DataGridView dgv)
        {
            dgv.AllowUserToAddRows = false;
            dgv.RowHeadersVisible = false;
            dgv.ColumnHeadersVisible = false;
            dgv.ScrollBars = ScrollBars.None;
            dgv.AllowUserToResizeColumns = false;
            dgv.AllowUserToResizeRows = false;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
        }

        private void SetupDataGridView(DataGridView dgv)
        {
            ConfigurarGrid(dgv);
            dgv.Columns.Clear();
            dgv.Rows.Clear();
            int n = (int)numericUpDown1.Value;

            // Calcular el ancho de las columnas basado en el ancho total del DataGridView
            int columnWidth = dgv.Width / n;
            int rowHeight = (dgv.Height / n) - 1;

            // Agregar columnas
            for (int i = 0; i < n; i++)
            {
                dgv.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    Width = columnWidth,
                    HeaderText = ""
                    });
            }

            // Agregar filas
            for (int i = 0; i < n; i++)
            {
                dgv.Rows.Add();
            }

            // Ajustar altura de filas basado en la altura total del DataGridView
            if (dgv.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in dgv.Rows)
                row.Height = rowHeight;
            }
        }

        private double[,] LeerMatrizDGV(DataGridView dgv)
        {
            int filas = dgv.Rows.Count;
            int columnas = dgv.Columns.Count;
            double[,] matriz = new double[filas, columnas];

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    object valorCelda = dgv.Rows[i].Cells[j].Value;
                    if (valorCelda == null || !double.TryParse(valorCelda.ToString(), out double valor))
                    {
                        MessageBox.Show("Ingrese valores numéricos en todas las celdas", "Advertencia",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return null;
                    }
                    matriz[i, j] = valor;
                }
            }
            return matriz;
        }

        private double[,] CalcularTranspuesta(double[,] matriz)
        {
            if (matriz == null) return null;
            int n = matriz.GetLength(0);
            double[,] transpuesta = new double[n, n];

            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    transpuesta[j, i] = matriz[i, j];

            return transpuesta;
        }

        private void MostrarMatriz(double[,] matriz, DataGridView dgv)
        {
            int filas = matriz.GetLength(0);
            int columnas = matriz.GetLength(1);

            dgv.Columns.Clear();
            dgv.Rows.Clear();
            ConfigurarGrid(dgv);
          
            // Calcular el ancho de las columnas y la altura de las filas basado en el tamaño del DataGridView
            int columnWidth = dgv.Width / columnas;
            int rowHeight = (dgv.Height / filas)-1;

            // Agregar las columnas y configurar su ancho
            for (int j = 0; j < columnas; j++)
            {
                DataGridViewTextBoxColumn col = new DataGridViewTextBoxColumn()
                {
                    Width = columnWidth,
                    HeaderText = ""
                };
                dgv.Columns.Add(col);
            }

            // Agregar filas y asignar la altura, además de llenar cada celda con el valor correspondiente
            for (int i = 0; i < filas; i++)
            {
                int rowIndex = dgv.Rows.Add();
                dgv.Rows[rowIndex].Height = rowHeight;
                for (int j = 0; j < columnas; j++)
                {
                    dgv.Rows[rowIndex].Cells[j].Value = matriz[i, j];
                }
            }
        }

        private double CalcularDiagonalPrincipal(double[,] matriz)
        {
            int n = matriz.GetLength(0);
            double diagonal = 0;
            for (int i = 0; i < n; i++)
            {
                diagonal += matriz[i, i];
            }
            return diagonal;
        }

        // Diagonal secundaria
        private double CalcularDiagonalSecundaria(double[,] matriz)
        {
            int n = matriz.GetLength(0);
            double diagonal = 0;
            for (int i = 0; i < n; i++)
            {
                diagonal += matriz[i, n - i - 1];
            }
            return diagonal;
        }

        // Verificar si es simétrica
        private String VerificarSimetria(double[,] matriz)
        {
            bool simetrica = true;
            if (matriz.GetLength(0) != matriz.GetLength(1)) return "NO TIENE";

            int n = matriz.GetLength(0);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (matriz[i, j] != matriz[j, i])
                    {
                        simetrica = false;
                        return "NO TIENE";
                    }
                }
                if (!simetrica) break;
            }
            return "SI TIENE";
        }

        private void Limpiar()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
            dataGridView2.Rows.Clear();
            dataGridView2.Columns.Clear();
            lblNormalPrincipal.Text = "";
            lblNormalSecundaria.Text = "";
            lblInvertidaPrincipal.Text = "";
            lblInvertidaSecundaria.Text = "";
            lblSimetrica.Text = "______________";
        }

        private void Matriz_Load(object sender, EventArgs e)
        {

        }

        

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Menu form = new Menu();
            form.Show();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //No realiza ningun calculo si no se ha creado la matriz
            if (dataGridView1.Columns.Count == 0 || dataGridView1.Rows.Count == 0) return;
            
            double[,] matrizOriginal = LeerMatrizDGV(dataGridView1);
            double[,] matrizTranspuesta = CalcularTranspuesta(matrizOriginal);
            if (matrizTranspuesta == null) return;
            MostrarMatriz(matrizTranspuesta, dataGridView2);

            lblNormalPrincipal.Text = CalcularDiagonalPrincipal(matrizOriginal).ToString();
            lblNormalSecundaria.Text = CalcularDiagonalSecundaria(matrizOriginal).ToString();

            lblInvertidaPrincipal.Text = CalcularDiagonalPrincipal(matrizTranspuesta).ToString();
            lblInvertidaSecundaria.Text = CalcularDiagonalSecundaria(matrizTranspuesta).ToString();

            lblSimetrica.Text = VerificarSimetria(matrizOriginal).ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void btnAyuda_Click(object sender, EventArgs e)
        {
            Ayuda ayuda = new Ayuda();
            ayuda.ShowDialog();
        }

        private void btnCrear_Click_1(object sender, EventArgs e)
        {

        }
    }
}
