﻿using AnimalViewerAPI.DAL;
using AnimalViewerAPI.Entities;

namespace AnimalViewerAPI.BLL
{
    public class AnimalService
    {
        private AnimalAPI api = new AnimalAPI();

        public Animal ObtenerAnimal()
        {
            return api.GetAnimal();
        }
    }
}

