﻿using AnimalViewerAPI.Entities;
using Newtonsoft.Json;
using System.Net.Http;

namespace AnimalViewerAPI.DAL
{
    public class AnimalAPI
    {
        private readonly string url = "https://zoo-animal-api.vercel.app/api/animals/rand";

        public Animal GetAnimal()
        {
            using (HttpClient client = new HttpClient())
            {
                var response = client.GetStringAsync(url).Result;
                return JsonConvert.DeserializeObject<Animal>(response);
            }
        }
    }
}

