﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace AnimalViewerAPI
{
    public partial class Form2 : Form
    {
        private static readonly HttpClient client = new HttpClient();

        private Label lblNombreValor;
        private Label lblTipoValor;
        private Label lblDietaValor;
        private Label lblHabitatValor;
        private Button btnObtener;

        public Form2()
        {
            // Llamar a InitializeFormControls manualmente
            InitializeFormControls();
        }

        private void InitializeFormControls()
        {
            // Inicializando controles manualmente
            lblNombreValor = new Label() { Location = new System.Drawing.Point(150, 70) };
            lblTipoValor = new Label() { Location = new System.Drawing.Point(150, 100) };
            lblDietaValor = new Label() { Location = new System.Drawing.Point(150, 130) };
            lblHabitatValor = new Label() { Location = new System.Drawing.Point(150, 160) };

            // Agregamos los controles al formulario
            this.Controls.Add(lblNombreValor);
            this.Controls.Add(lblTipoValor);
            this.Controls.Add(lblDietaValor);
            this.Controls.Add(lblHabitatValor);

            // Inicializando el botón
            btnObtener = new Button() { Text = "Obtener Datos", Location = new System.Drawing.Point(20, 200) };
            btnObtener.Click += btnObtener_Click;

            // Agregar el botón al formulario
            this.Controls.Add(btnObtener);
        }

        private async void btnObtener_Click(object sender, EventArgs e)
        {
            string artistName = "Adele"; // Ejemplo de nombre de artista
            string url = $"https://api.deezer.com/search?q={artistName}";

            var result = await ObtenerDatosDeDeezer(url);

            if (result != null)
            {
                lblNombreValor.Text = result.Name;
                lblTipoValor.Text = result.Type;
                lblDietaValor.Text = result.Diet ?? "-";
                lblHabitatValor.Text = result.Habitat ?? "-";
            }
            else
            {
                MessageBox.Show("No se encontraron datos.");
            }
        }

        private async Task<DeezerArtist> ObtenerDatosDeDeezer(string url)
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode();

                string responseBody = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<DeezerSearchResult>(responseBody);

                return result.Data.Length > 0 ? result.Data[0] : null;
            }
            catch (Exception e)
            {
                MessageBox.Show($"Error al obtener los datos: {e.Message}");
                return null;
            }
        }
    }

    // Clases para manejar la respuesta de la API
    public class DeezerSearchResult
    {
        [JsonProperty("data")]
        public DeezerArtist[] Data { get; set; }
    }

    public class DeezerArtist
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("diet")]
        public string Diet { get; set; }

        [JsonProperty("habitat")]
        public string Habitat { get; set; }
    }
}
