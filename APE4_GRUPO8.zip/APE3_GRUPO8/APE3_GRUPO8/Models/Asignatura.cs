﻿using System.ComponentModel.DataAnnotations;

namespace APE3_GRUPO8.Models
{
    public class Asignatura
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre de la asignatura es obligatoria")]
        [StringLength(50, MinimumLength = 4, ErrorMessage = "El nombre debe tener entre 4 y 50 caracteres")]
        public string Nombre { get; set; } = null!;
        public ICollection<Nota> Notas { get; set; } = new List<Nota>();
    }
}
