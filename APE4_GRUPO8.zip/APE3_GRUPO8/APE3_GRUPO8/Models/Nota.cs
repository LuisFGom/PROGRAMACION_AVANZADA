﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace APE3_GRUPO8.Models
{
    public class Nota
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int EstudianteId { get; set; }
        [ForeignKey("EstudianteId")]
        public Estudiante? Estudiante { get; set; }

        [Required]
        public int AsignaturaId { get; set; }
        [ForeignKey("AsignaturaId")]
        public Asignatura? Asignatura { get; set; }

        [Required(ErrorMessage = "La calificacion es obligatoria")]
        [Precision(5, 2)]
        [Range(0, 10, ErrorMessage = "La calificación debe estar entre 0 y 10")]
        public decimal NotaPrimerParcial { get; set; }

        [Required(ErrorMessage = "La calificacion es obligatoria")]
        [Precision(5, 2)]
        [Range(0, 10, ErrorMessage = "La calificación debe estar entre 0 y 10")]
        public decimal NotaSegundoParcial { get; set; }

        [Precision(5, 2)]
        [Range(0, 10, ErrorMessage = "La calificación debe estar entre 0 y 10")]
        public decimal? NotaSupletorio { get; set; }
        [Required]
        public string Estado { get; set; } = null!;

    }
}
