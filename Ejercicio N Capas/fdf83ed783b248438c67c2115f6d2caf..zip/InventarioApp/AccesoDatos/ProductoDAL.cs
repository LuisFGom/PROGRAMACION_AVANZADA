﻿using System.Data.SqlClient;
using System.Configuration;
using InventarioApp.Entidades;

namespace InventarioApp.AccesoDatos
{
    public class ProductoDAL
    {
        private string conexion = "Data Source=DESKTOP-LMLUBQI\\SQLEXPRESS;Initial Catalog=InventarioDB;Integrated Security=True";

        public void AgregarProducto(Producto producto)
        {
            using (SqlConnection conn = new SqlConnection(conexion))
            {
                string query = "INSERT INTO Productos (Nombre, Cantidad, Precio) VALUES (@Nombre, @Cantidad, @Precio)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", producto.Nombre);
                cmd.Parameters.AddWithValue("@Cantidad", producto.Cantidad);
                cmd.Parameters.AddWithValue("@Precio", producto.Precio);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
