﻿using InventarioApp.Entidades;
using InventarioApp.AccesoDatos;
using System;

namespace InventarioApp.LogicaNegocio
{
    public class ProductoBL
    {
        private ProductoDAL productoDAL = new ProductoDAL();

        public void AgregarProducto(Producto producto)
        {
            if (producto.Cantidad < 0 || producto.Precio < 0)
                throw new ArgumentException("Cantidad y Precio deben ser positivos.");

            productoDAL.AgregarProducto(producto);
        }
    }
}