﻿using Microsoft.EntityFrameworkCore;
using NOTAS_APE.Data;
using NOTAS_APE.Models;
using NOTAS_APE.Utilidades;

namespace NOTAS_APE.Repositories
{
    public class EstudianteRepository : IEstudianteRepository
    {
        private readonly ApplicationDbContext _context;

        public EstudianteRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Estudiante>> GetAllAsync()
        {
            try
            {
                return await _context.Estudiantes.ToListAsync();
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return Enumerable.Empty<Estudiante>();
            }
        }

        public async Task<Estudiante> GetByCedulaAsync(string cedula)
        {
            try
            {
                return await _context.Estudiantes.FirstOrDefaultAsync(e => e.Cedula == cedula);
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return null;
            }
        }

        public async Task AddAsync(Estudiante estudiante)
        {
            try
            {
                await _context.Estudiantes.AddAsync(estudiante);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
            }
        }

        public async Task<IEnumerable<Estudiante>> FiltrarAsync(string? cedula, string? apellido)
        {
            try
            {
                var query = _context.Estudiantes.AsQueryable();

                if (!string.IsNullOrEmpty(cedula))
                    query = query.Where(e => e.Cedula.Contains(cedula));

                if (!string.IsNullOrEmpty(apellido))
                    query = query.Where(e => e.Apellido.Contains(apellido));

                return await query.ToListAsync();
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return Enumerable.Empty<Estudiante>();
            }
        }
    }
}
