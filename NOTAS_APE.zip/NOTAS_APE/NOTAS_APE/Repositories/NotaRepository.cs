﻿using NOTAS_APE.Data;
using NOTAS_APE.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using NOTAS_APE.Utilidades;

namespace NOTAS_APE.Repositories
{
    public class NotaRepository : INotaRepository
    {
        private readonly ApplicationDbContext _context;

        public NotaRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Nota>> GetAllNotasAsync()
        {
            try
            {
                return await _context.Notas
                    .Include(n => n.Estudiante)
                    .Include(n => n.Curso)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return Enumerable.Empty<Nota>();
            }
        }

        public async Task<Nota> GetNotaByIdAsync(int id)
        {
            try
            {
                return await _context.Notas
                    .Include(n => n.Estudiante)
                    .Include(n => n.Curso)
                    .FirstOrDefaultAsync(n => n.Id == id);
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return null;
            }
        }

        public async Task<Nota> CrearNotaAsync(Nota nota)
        {
            var query = @"
                INSERT INTO Notas (cedula_es, curso_id, nota, fecha_registro) 
                VALUES (@p0, @p1, @p2, @p3); 
                SELECT SCOPE_IDENTITY();";

            using var connection = _context.Database.GetDbConnection();
            await connection.OpenAsync();

            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();

            command.Transaction = transaction;
            command.CommandText = query;
            command.CommandType = System.Data.CommandType.Text;

            command.Parameters.Add(new SqlParameter("@p0", nota.CedulaEstudiante));
            command.Parameters.Add(new SqlParameter("@p1", nota.CursoId));
            command.Parameters.Add(new SqlParameter("@p2", nota.Valor));
            command.Parameters.Add(new SqlParameter("@p3", nota.FechaRegistro));

            try
            {
                var result = await command.ExecuteScalarAsync();
                nota.Id = Convert.ToInt32(result);
                await transaction.CommitAsync();
                return nota;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                ManejadorExcepciones.Manejar(ex);
                return null;
            }
        }

        public async Task<bool> ActualizarNotaAsync(int id, decimal nuevaNota)
        {
            var query = @"
                UPDATE Notas 
                SET nota = @p0, fecha_registro = @p1 
                WHERE id = @p2";

            using var connection = _context.Database.GetDbConnection();
            await connection.OpenAsync();

            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();

            command.Transaction = transaction;
            command.CommandText = query;
            command.CommandType = System.Data.CommandType.Text;

            command.Parameters.Add(new SqlParameter("@p0", nuevaNota));
            command.Parameters.Add(new SqlParameter("@p1", DateTime.Now));
            command.Parameters.Add(new SqlParameter("@p2", id));

            try
            {
                var rowsAffected = await command.ExecuteNonQueryAsync();
                await transaction.CommitAsync();
                return rowsAffected > 0;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                ManejadorExcepciones.Manejar(ex);
                return false;
            }
        }
    }
}
