﻿using System;
using System.Data.SqlClient;

namespace NOTAS_APE.Utilidades
{
    public class ManejadorExcepciones
    {
        public static void Manejar(SqlException ex)
        {
            Console.WriteLine($"[ERROR SQL] {ex.Message}");
            throw ex; // Correcto aquí
        }

        public static void Manejar(Exception ex)
        {
            Console.WriteLine($"[ERROR GENERAL] {ex.Message}");
            throw ex;
        }
    }
}
