﻿using Microsoft.AspNetCore.Mvc;
using NOTAS_APE.DTOs;
using NOTAS_APE.Services;
using NOTAS_APE.Utilidades;

namespace NOTAS_APE.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PromediosController : ControllerBase
    {
        private readonly PromedioService _service;

        public PromediosController(PromedioService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PromedioDTO>>> Get()
        {
            try
            {
                var promedios = await _service.GetPromediosDTOAsync();
                return Ok(promedios);
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return StatusCode(500, "Error al obtener los promedios");
            }
        }
    }
}