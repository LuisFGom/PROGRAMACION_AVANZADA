﻿using NOTAS_APE.Models;
using NOTAS_APE.Repositories;
using NOTAS_APE.Utilidades;

namespace NOTAS_APE.Services
{
    public class EstudianteService
    {
        private readonly IEstudianteRepository _repository;

        public EstudianteService(IEstudianteRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Estudiante>> GetEstudiantesAsync()
        {
            try
            {
                return await _repository.GetAllAsync();
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return Enumerable.Empty<Estudiante>();
            }
        }

        public async Task<IEnumerable<Estudiante>> FiltrarEstudiantesAsync(string? cedula, string? apellido)
        {
            try
            {
                return await _repository.FiltrarAsync(cedula, apellido);
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return Enumerable.Empty<Estudiante>();
            }
        }
    }
}
