﻿using NOTAS_APE.DTOs;
using NOTAS_APE.Repositories;
using NOTAS_APE.Utilidades;

namespace NOTAS_APE.Services
{
    public class PromedioService
    {
        private readonly IPromedioRepository _repository;

        public PromedioService(IPromedioRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<PromedioDTO>> GetPromediosDTOAsync()
        {
            try
            {
                return await _repository.GetAllPromediosConCursoAsync();
            }
            catch (Exception ex)
            {
                ManejadorExcepciones.Manejar(ex);
                return Enumerable.Empty<PromedioDTO>();
            }
        }
    }
}
