﻿using Microsoft.AspNetCore.Mvc;
using BancoAPI.Services;
using BancoAPI.DTOs;

namespace BancoAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CuentasController : ControllerBase
    {
        private readonly IBancoService _bancoService;
        private readonly ILogger<CuentasController> _logger;

        public CuentasController(IBancoService bancoService, ILogger<CuentasController> logger)
        {
            _bancoService = bancoService;
            _logger = logger;
        }

        /// <summary>
        /// Obtiene todas las cuentas
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<ApiResponse<List<CuentaResponse>>>> GetCuentas()
        {
            try
            {
                var cuentas = await _bancoService.ObtenerCuentasAsync();
                var cuentasResponse = cuentas.Select(c => new CuentaResponse
                {
                    Numero = c.Numero,
                    Tipo = c.Tipo,
                    Saldo = c.Saldo,
                    CedulaCliente = c.CedulaCliente,
                    Existe = true
                }).ToList();

                return Ok(new ApiResponse<List<CuentaResponse>>
                {
                    Success = true,
                    Message = "Cuentas obtenidas exitosamente",
                    Data = cuentasResponse
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener cuentas");
                return StatusCode(500, new ApiResponse<List<CuentaResponse>>
                {
                    Success = false,
                    Message = "Error interno del servidor"
                });
            }
        }

        /// <summary>
        /// Obtiene información de una cuenta específica
        /// </summary>
        [HttpGet("{numero}")]
        public async Task<ActionResult<ApiResponse<CuentaResponse>>> GetCuenta(string numero)
        {
            try
            {
                var cuenta = await _bancoService.ObtenerCuentaAsync(numero);

                if (cuenta == null)
                {
                    return NotFound(new ApiResponse<CuentaResponse>
                    {
                        Success = false,
                        Message = "Cuenta no encontrada"
                    });
                }

                var cuentaResponse = new CuentaResponse
                {
                    Numero = cuenta.Numero,
                    Tipo = cuenta.Tipo,
                    Saldo = cuenta.Saldo,
                    CedulaCliente = cuenta.CedulaCliente,
                    Existe = true
                };

                return Ok(new ApiResponse<CuentaResponse>
                {
                    Success = true,
                    Message = "Cuenta encontrada",
                    Data = cuentaResponse
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener cuenta {Numero}", numero);
                return StatusCode(500, new ApiResponse<CuentaResponse>
                {
                    Success = false,
                    Message = "Error interno del servidor"
                });
            }
        }

        /// <summary>
        /// Obtiene el saldo de una cuenta
        /// </summary>
        [HttpGet("{numero}/saldo")]
        public async Task<ActionResult<ApiResponse<decimal>>> GetSaldo(string numero)
        {
            try
            {
                var existe = await _bancoService.CuentaExisteAsync(numero);
                if (!existe)
                {
                    return NotFound(new ApiResponse<decimal>
                    {
                        Success = false,
                        Message = "Cuenta no encontrada"
                    });
                }

                var saldo = await _bancoService.ObtenerSaldoAsync(numero);
                return Ok(new ApiResponse<decimal>
                {
                    Success = true,
                    Message = "Saldo obtenido exitosamente",
                    Data = saldo
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener saldo de cuenta {Numero}", numero);
                return StatusCode(500, new ApiResponse<decimal>
                {
                    Success = false,
                    Message = "Error interno del servidor"
                });
            }
        }

        /// <summary>
        /// Verifica si una cuenta existe
        /// </summary>
        [HttpGet("{numero}/existe")]
        public async Task<ActionResult<ApiResponse<bool>>> CuentaExiste(string numero)
        {
            try
            {
                var existe = await _bancoService.CuentaExisteAsync(numero);
                return Ok(new ApiResponse<bool>
                {
                    Success = true,
                    Message = existe ? "La cuenta existe" : "La cuenta no existe",
                    Data = existe
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al verificar existencia de cuenta {Numero}", numero);
                return StatusCode(500, new ApiResponse<bool>
                {
                    Success = false,
                    Message = "Error interno del servidor"
                });
            }
        }
    }
}