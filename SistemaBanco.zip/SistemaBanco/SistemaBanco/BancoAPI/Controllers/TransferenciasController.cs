﻿using Microsoft.AspNetCore.Mvc;
using BancoAPI.Services;
using BancoAPI.DTOs;
using BancoAPI.Models;

namespace BancoAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransferenciasController : ControllerBase
    {
        private readonly IBancoService _bancoService;
        private readonly ILogger<TransferenciasController> _logger;

        public TransferenciasController(IBancoService bancoService, ILogger<TransferenciasController> logger)
        {
            _bancoService = bancoService;
            _logger = logger;
        }

        /// <summary>
        /// Realiza una transferencia entre cuentas
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<TransferenciaResponse>> RealizarTransferencia([FromBody] TransferenciaRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(new TransferenciaResponse
                    {
                        Success = false,
                        Message = "Datos de transferencia inválidos"
                    });
                }

                // Validaciones adicionales
                if (request.CuentaOrigen == request.CuentaDestino)
                {
                    return BadRequest(new TransferenciaResponse
                    {
                        Success = false,
                        Message = "La cuenta origen no puede ser igual a la cuenta destino"
                    });
                }

                // Crear objeto transferencia
                var transferencia = new Transferencia
                {
                    CuentaOrigen = request.CuentaOrigen,
                    CuentaDestino = request.CuentaDestino,
                    Valor = request.Valor,
                    Fecha = DateTime.Now
                };

                // Realizar transferencia
                var resultado = await _bancoService.TransferirAsync(transferencia);

                if (resultado)
                {
                    return Ok(new TransferenciaResponse
                    {
                        Success = true,
                        Message = "Transferencia realizada exitosamente",
                        NumeroTransferencia = transferencia.Numero,
                        FechaTransferencia = transferencia.Fecha,
                        ValorTransferido = transferencia.Valor,
                        CuentaOrigen = transferencia.CuentaOrigen,
                        CuentaDestino = transferencia.CuentaDestino
                    });
                }

                return BadRequest(new TransferenciaResponse
                {
                    Success = false,
                    Message = "No se pudo completar la transferencia"
                });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Error de validación en transferencia");
                return BadRequest(new TransferenciaResponse
                {
                    Success = false,
                    Message = ex.Message
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error interno en transferencia");
                return StatusCode(500, new TransferenciaResponse
                {
                    Success = false,
                    Message = "Error interno del servidor"
                });
            }
        }

        /// <summary>
        /// Obtiene el historial de transferencias de una cuenta
        /// </summary>
        [HttpGet("historial/{numeroCuenta}")]
        public async Task<ActionResult<ApiResponse<List<Transferencia>>>> GetHistorialTransferencias(string numeroCuenta)
        {
            try
            {
                var existe = await _bancoService.CuentaExisteAsync(numeroCuenta);
                if (!existe)
                {
                    return NotFound(new ApiResponse<List<Transferencia>>
                    {
                        Success = false,
                        Message = "Cuenta no encontrada"
                    });
                }

                var transferencias = await _bancoService.ObtenerTransferenciasAsync(numeroCuenta);

                return Ok(new ApiResponse<List<Transferencia>>
                {
                    Success = true,
                    Message = "Historial obtenido exitosamente",
                    Data = transferencias
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener historial de transferencias para cuenta {NumeroCuenta}", numeroCuenta);
                return StatusCode(500, new ApiResponse<List<Transferencia>>
                {
                    Success = false,
                    Message = "Error interno del servidor"
                });
            }
        }
    }
}