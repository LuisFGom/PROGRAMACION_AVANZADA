using Microsoft.EntityFrameworkCore;
using BancoAPI.Data;
using BancoAPI.Services;
using BancoAPI.Middleware;

var builder = WebApplication.CreateBuilder(args);

// Agregar servicios al contenedor
builder.Services.AddControllers();

// Configurar Entity Framework
builder.Services.AddDbContext<BancoDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Registrar servicios personalizados
builder.Services.AddScoped<IBancoService, BancoService>();

// Configurar Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new()
    {
        Title = "Banco API",
        Version = "v1",
        Description = "API para sistema bancario con transferencias"
    });
});

// Configurar CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});


var app = builder.Build();

// Configurar el pipeline HTTP
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Banco API v1");
        c.RoutePrefix = "swagger"; // Acceder en /swagger
    });
}

// Middleware personalizado para manejo de errores
app.UseMiddleware<ExceptionMiddleware>();

app.UseHttpsRedirection();

// Habilitar archivos est�ticos (para el frontend)
app.UseStaticFiles();

// Habilitar CORS
app.UseCors("AllowAll");

app.UseAuthorization();

app.MapControllers();

// Ruta por defecto para el frontend
app.MapFallbackToFile("index.html");

app.Run();