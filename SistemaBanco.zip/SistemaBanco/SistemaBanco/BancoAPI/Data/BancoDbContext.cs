﻿using Microsoft.EntityFrameworkCore;
using BancoAPI.Models;

namespace BancoAPI.Data
{
    public class BancoDbContext : DbContext
    {
        public BancoDbContext(DbContextOptions<BancoDbContext> options) : base(options)
        {
        }

        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Cuenta> Cuentas { get; set; }
        public DbSet<Transferencia> Transferencias { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuración de Cliente
            modelBuilder.Entity<Cliente>(entity =>
            {
                entity.ToTable("CLIENTES");
                entity.HasKey(e => e.Cedula);
                entity.Property(e => e.Cedula).HasColumnName("CED_CLI").HasMaxLength(20);
                entity.Property(e => e.Nombre).HasColumnName("NOM_CLI").HasMaxLength(100).IsRequired();
                entity.Property(e => e.Apellido).HasColumnName("APE_CLI").HasMaxLength(100).IsRequired();
            });

            // Configuración de Cuenta
            modelBuilder.Entity<Cuenta>(entity =>
            {
                entity.ToTable("CUENTAS");
                entity.HasKey(e => e.Numero);
                entity.Property(e => e.Numero).HasColumnName("NUM_CUE").HasMaxLength(20);
                entity.Property(e => e.Tipo).HasColumnName("TIP_CUE").HasMaxLength(50).IsRequired();
                entity.Property(e => e.Saldo).HasColumnName("SAL_CUE").HasColumnType("decimal(18,2)");
                entity.Property(e => e.CedulaCliente).HasColumnName("CED_CLI").HasMaxLength(20).IsRequired();

                // Relación con Cliente
                entity.HasOne<Cliente>()
                    .WithMany()
                    .HasForeignKey(e => e.CedulaCliente)
                    .HasPrincipalKey(c => c.Cedula);
            });

            // Configuración de Transferencia
            modelBuilder.Entity<Transferencia>(entity =>
            {
                entity.ToTable("TRANSFERENCIAS");
                entity.HasKey(e => e.Numero);
                entity.Property(e => e.Numero).HasColumnName("NUM_TRA").ValueGeneratedOnAdd();
                entity.Property(e => e.Fecha).HasColumnName("FEC_TRA").HasDefaultValueSql("GETDATE()");
                entity.Property(e => e.Valor).HasColumnName("VALOR_TRA").HasColumnType("decimal(18,2)");
                entity.Property(e => e.CuentaOrigen).HasColumnName("NUM_CUE_ORI").HasMaxLength(20).IsRequired();
                entity.Property(e => e.CuentaDestino).HasColumnName("NUM_CUE_DES").HasMaxLength(20).IsRequired();

                // Relaciones con Cuentas
                entity.HasOne<Cuenta>()
                    .WithMany()
                    .HasForeignKey(e => e.CuentaOrigen)
                    .HasPrincipalKey(c => c.Numero)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne<Cuenta>()
                    .WithMany()
                    .HasForeignKey(e => e.CuentaDestino)
                    .HasPrincipalKey(c => c.Numero)
                    .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}