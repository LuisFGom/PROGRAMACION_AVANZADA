﻿using Microsoft.EntityFrameworkCore;
using BancoAPI.Data;
using BancoAPI.Models;

namespace BancoAPI.Services
{
    public class BancoService : IBancoService
    {
        private readonly BancoDbContext _context;
        private readonly ILogger<BancoService> _logger;

        public BancoService(BancoDbContext context, ILogger<BancoService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<bool> CuentaExisteAsync(string numeroCuenta)
        {
            return await _context.Cuentas.AnyAsync(c => c.Numero == numeroCuenta);
        }

        public async Task<decimal> ObtenerSaldoAsync(string numeroCuenta)
        {
            var cuenta = await _context.Cuentas.FirstOrDefaultAsync(c => c.Numero == numeroCuenta);
            return cuenta?.Saldo ?? 0;
        }

        public async Task<Cuenta?> ObtenerCuentaAsync(string numeroCuenta)
        {
            return await _context.Cuentas.FirstOrDefaultAsync(c => c.Numero == numeroCuenta);
        }

        public async Task<List<Cuenta>> ObtenerCuentasAsync()
        {
            return await _context.Cuentas.ToListAsync();
        }

        public async Task<List<Transferencia>> ObtenerTransferenciasAsync(string numeroCuenta)
        {
            return await _context.Transferencias
                .Where(t => t.CuentaOrigen == numeroCuenta || t.CuentaDestino == numeroCuenta)
                .OrderByDescending(t => t.Fecha)
                .ToListAsync();
        }

        public async Task<bool> TransferirAsync(Transferencia transferencia)
        {
            using var transaction = await _context.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);
            
            try
            {
                _logger.LogInformation($"Iniciando transferencia de {transferencia.CuentaOrigen} a {transferencia.CuentaDestino} por ${transferencia.Valor}");

                // Verificar cuenta origen y saldo
                var cuentaOrigen = await _context.Cuentas.FirstOrDefaultAsync(c => c.Numero == transferencia.CuentaOrigen);
                if (cuentaOrigen == null)
                    throw new InvalidOperationException("La cuenta origen no existe");

                if (cuentaOrigen.Saldo < transferencia.Valor)
                    throw new InvalidOperationException($"Saldo insuficiente. Disponible: ${cuentaOrigen.Saldo}");

                // Verificar cuenta destino
                var cuentaDestino = await _context.Cuentas.FirstOrDefaultAsync(c => c.Numero == transferencia.CuentaDestino);
                if (cuentaDestino == null)
                    throw new InvalidOperationException("La cuenta destino no existe");

                // Realizar transferencia
                cuentaOrigen.Saldo -= transferencia.Valor;
                cuentaDestino.Saldo += transferencia.Valor;

                // Configurar datos de transferencia
                transferencia.Fecha = DateTime.Now;

                // Registrar transferencia
                _context.Transferencias.Add(transferencia);

                // Guardar cambios
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                _logger.LogInformation($"Transferencia completada exitosamente. ID: {transferencia.Numero}");
                return true;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, $"Error en transferencia: {ex.Message}");
                throw;
            }
        }
    }
}