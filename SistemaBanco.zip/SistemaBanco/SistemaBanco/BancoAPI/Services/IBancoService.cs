﻿using BancoAPI.Models;

namespace BancoAPI.Services
{
    public interface IBancoService
    {
        Task<bool> CuentaExisteAsync(string numeroCuenta);
        Task<decimal> ObtenerSaldoAsync(string numeroCuenta);
        Task<Cuenta?> ObtenerCuentaAsync(string numeroCuenta);
        Task<bool> TransferirAsync(Transferencia transferencia);
        Task<List<Transferencia>> ObtenerTransferenciasAsync(string numeroCuenta);
        Task<List<Cuenta>> ObtenerCuentasAsync();
    }
}