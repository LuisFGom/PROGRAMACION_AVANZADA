﻿namespace BancoAPI.DTOs
{
    public class CuentaResponse
    {
        public string Numero { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public decimal Saldo { get; set; }
        public string CedulaCliente { get; set; } = string.Empty;
        public bool Existe { get; set; }
    }

    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public T? Data { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }
}