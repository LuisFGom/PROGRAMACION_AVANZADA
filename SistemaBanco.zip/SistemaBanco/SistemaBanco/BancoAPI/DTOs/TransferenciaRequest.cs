﻿using System.ComponentModel.DataAnnotations;

namespace BancoAPI.DTOs
{
    public class TransferenciaRequest
    {
        [Required(ErrorMessage = "La cuenta origen es requerida")]
        [StringLength(20, ErrorMessage = "El número de cuenta no puede exceder 20 caracteres")]
        public string CuentaOrigen { get; set; } = string.Empty;

        [Required(ErrorMessage = "La cuenta destino es requerida")]
        [StringLength(20, ErrorMessage = "El número de cuenta no puede exceder 20 caracteres")]
        public string CuentaDestino { get; set; } = string.Empty;

        [Required(ErrorMessage = "El valor es requerido")]
        [Range(0.01, 999999.99, ErrorMessage = "El valor debe estar entre 0.01 y 999,999.99")]
        public decimal Valor { get; set; }
    }
}