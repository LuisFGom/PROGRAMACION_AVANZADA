﻿namespace BancoAPI.DTOs
{
    public class TransferenciaResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public int? NumeroTransferencia { get; set; }
        public DateTime? FechaTransferencia { get; set; }
        public decimal? ValorTransferido { get; set; }
        public string? CuentaOrigen { get; set; }
        public string? CuentaDestino { get; set; }
    }
}