﻿// Configuración de la API
const API_BASE_URL = '';  // URL vacía porque está en el mismo servidor

// Utilidades
function mostrarLoading(elementId, show = true) {
    const element = document.getElementById(elementId);
    if (show) {
        element.innerHTML = '<div class="text-center"><div class="spinner-border text-primary" role="status"></div></div>';
    }
}

function mostrarError(elementId, mensaje) {
    document.getElementById(elementId).innerHTML =
        `<div class="alert alert-danger"><strong>Error:</strong> ${mensaje}</div>`;
}

function mostrarExito(elementId, mensaje) {
    document.getElementById(elementId).innerHTML =
        `<div class="alert alert-success"><strong>Éxito:</strong> ${mensaje}</div>`;
}

// Función para consultar datos de una cuenta
async function consultarCuenta() {
    const numeroCuenta = document.getElementById('numeroCuenta').value.trim();

    if (!numeroCuenta) {
        mostrarError('resultadoCuenta', 'Por favor ingrese un número de cuenta');
        return;
    }

    mostrarLoading('resultadoCuenta');

    try {
        const response = await fetch(`${API_BASE_URL}/api/cuentas/${numeroCuenta}`);
        const result = await response.json();

        if (response.ok && result.success) {
            const cuenta = result.data; // ✅ Acceder a los datos dentro de ApiResponse
            document.getElementById('resultadoCuenta').innerHTML = `
                <div class="alert alert-info">
                    <h6>Datos de la Cuenta:</h6>
                    <strong>Número:</strong> ${cuenta.numero}<br>
                    <strong>Tipo:</strong> ${cuenta.tipo}<br>
                    <strong>Saldo:</strong> $${cuenta.saldo.toFixed(2)}<br>
                    <strong>Cliente:</strong> ${cuenta.cedulaCliente}
                </div>
            `;
        } else {
            mostrarError('resultadoCuenta', result.message || 'Cuenta no encontrada');
        }
    } catch (error) {
        console.error('Error en consultarCuenta:', error);
        mostrarError('resultadoCuenta', 'Error de conexión con el servidor');
    }
}

// Función para consultar solo el saldo
async function consultarSaldo() {
    const numeroCuenta = document.getElementById('numeroCuenta').value.trim();

    if (!numeroCuenta) {
        mostrarError('resultadoCuenta', 'Por favor ingrese un número de cuenta');
        return;
    }

    mostrarLoading('resultadoCuenta');

    try {
        const response = await fetch(`${API_BASE_URL}/api/cuentas/${numeroCuenta}/saldo`);
        const result = await response.json();

        if (response.ok && result.success) {
            const saldo = result.data; // ✅ Acceder al saldo dentro de ApiResponse
            document.getElementById('resultadoCuenta').innerHTML = `
                <div class="alert alert-success">
                    <h5>💰 Saldo Actual: $${saldo.toFixed(2)}</h5>
                </div>
            `;
        } else {
            mostrarError('resultadoCuenta', result.message || 'No se pudo obtener el saldo');
        }
    } catch (error) {
        console.error('Error en consultarSaldo:', error);
        mostrarError('resultadoCuenta', 'Error de conexión con el servidor');
    }
}

// Función para realizar transferencia
async function realizarTransferencia() {
    const cuentaOrigen = document.getElementById('cuentaOrigen').value.trim();
    const cuentaDestino = document.getElementById('cuentaDestino').value.trim();
    const valor = parseFloat(document.getElementById('valor').value);

    // Validaciones
    if (!cuentaOrigen || !cuentaDestino || !valor) {
        mostrarError('resultadoTransferencia', 'Todos los campos son requeridos');
        return;
    }

    if (valor <= 0) {
        mostrarError('resultadoTransferencia', 'El valor debe ser mayor a 0');
        return;
    }

    if (cuentaOrigen === cuentaDestino) {
        mostrarError('resultadoTransferencia', 'Las cuentas origen y destino deben ser diferentes');
        return;
    }

    mostrarLoading('resultadoTransferencia');

    try {
        const response = await fetch(`${API_BASE_URL}/api/transferencias`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                cuentaOrigen: cuentaOrigen,
                cuentaDestino: cuentaDestino,
                valor: valor
            })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            mostrarExito('resultadoTransferencia',
                `Transferencia exitosa. Número: ${result.numeroTransferencia}<br>
                 Fecha: ${new Date(result.fechaTransferencia).toLocaleString()}`
            );

            // Limpiar formulario
            document.getElementById('cuentaOrigen').value = '';
            document.getElementById('cuentaDestino').value = '';
            document.getElementById('valor').value = '';

            // Actualizar lista de cuentas si está visible
            const listaCuentas = document.getElementById('listaCuentas');
            if (listaCuentas && listaCuentas.innerHTML.includes('table')) {
                cargarCuentas();
            }
        } else {
            mostrarError('resultadoTransferencia', result.message || 'Error en la transferencia');
        }
    } catch (error) {
        console.error('Error en realizarTransferencia:', error);
        mostrarError('resultadoTransferencia', 'Error de conexión con el servidor');
    }
}

// Función para cargar la lista de cuentas
async function cargarCuentas() {
    mostrarLoading('listaCuentas');

    try {
        const response = await fetch(`${API_BASE_URL}/api/cuentas`);
        const result = await response.json();

        if (response.ok && result.success) {
            const cuentas = result.data; // ✅ Acceder a las cuentas dentro de ApiResponse

            if (!cuentas || cuentas.length === 0) {
                document.getElementById('listaCuentas').innerHTML =
                    '<div class="alert alert-warning">No hay cuentas registradas</div>';
                return;
            }

            let html = `
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Número</th>
                                <th>Tipo</th>
                                <th>Saldo</th>
                                <th>Cliente</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            cuentas.forEach(cuenta => {
                html += `
                    <tr>
                        <td><strong>${cuenta.numero}</strong></td>
                        <td><span class="badge bg-primary">${cuenta.tipo}</span></td>
                        <td><strong>$${cuenta.saldo.toFixed(2)}</strong></td>
                        <td>${cuenta.cedulaCliente}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-info" 
                                    onclick="copiarNumero('${cuenta.numero}')">
                                📋 Copiar
                            </button>
                        </td>
                    </tr>
                `;
            });

            html += `
                        </tbody>
                    </table>
                </div>
                <div class="text-muted small">
                    Total de cuentas: ${cuentas.length}
                </div>
            `;

            document.getElementById('listaCuentas').innerHTML = html;
        } else {
            mostrarError('listaCuentas', result.message || 'Error al cargar las cuentas');
        }
    } catch (error) {
        console.error('Error en cargarCuentas:', error);
        mostrarError('listaCuentas', 'Error de conexión con el servidor');
    }
}

// Función auxiliar para copiar número de cuenta
function copiarNumero(numero) {
    navigator.clipboard.writeText(numero).then(() => {
        // Mostrar feedback visual
        const btn = event.target;
        const textoOriginal = btn.innerHTML;
        btn.innerHTML = '✅ Copiado';
        btn.classList.add('btn-success');
        btn.classList.remove('btn-outline-info');

        setTimeout(() => {
            btn.innerHTML = textoOriginal;
            btn.classList.remove('btn-success');
            btn.classList.add('btn-outline-info');
        }, 2000);
    }).catch(err => {
        console.error('Error al copiar:', err);
    });
}

// Cargar cuentas al iniciar la página
document.addEventListener('DOMContentLoaded', function () {
    console.log('Sistema Bancario Frontend cargado correctamente');

    // Cargar cuentas automáticamente si existe el contenedor
    const listaCuentas = document.getElementById('listaCuentas');
    if (listaCuentas) {
        cargarCuentas();
    }
});