﻿using Microsoft.AspNetCore.Mvc;
using Evaluación_Practica_Segundo_Parcial.Data.Ef;
using Evaluación_Practica_Segundo_Parcial.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Evaluación_Practica_Segundo_Parcial.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PersonajeEfController : ControllerBase
    {
        private readonly EfPersonaje _efPersonaje;

        public PersonajeEfController(AppDbContext context)
        {
            _efPersonaje = new EfPersonaje(context);
        }

        [HttpPost]
        public async Task<IActionResult> Insertar(Personaje personaje)
        {
            await _efPersonaje.InsertarPersonajeAsync(personaje);
            return Ok("Personaje insertado con EF");
        }

        [HttpGet]
        public async Task<ActionResult<List<Personaje>>> Obtener()
        {
            var personajes = await _efPersonaje.ObtenerPersonajesAsync();
            return Ok(personajes);
        }
    }
}
