﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Evaluación_Practica_Segundo_Parcial.Data.Ado;
using Evaluación_Practica_Segundo_Parcial.Models;
using System.Collections.Generic;

namespace Evaluación_Practica_Segundo_Parcial.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PersonajeAdoController : ControllerBase
    {
        private readonly AdoPersonaje _adoPersonaje;

        public PersonajeAdoController(IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("DefaultConnection");
            _adoPersonaje = new AdoPersonaje(connectionString);
        }

        [HttpPost]
        public IActionResult Insertar(Personaje personaje)
        {
            _adoPersonaje.InsertarPersonaje(personaje);
            return Ok("Personaje insertado con ADO.NET");
        }

        [HttpGet]
        public ActionResult<List<Personaje>> Obtener()
        {
            var personajes = _adoPersonaje.ObtenerPersonajes();
            return Ok(personajes);
        }
    }
}
