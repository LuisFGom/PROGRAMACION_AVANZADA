﻿using Microsoft.EntityFrameworkCore;
using Evaluación_Practica_Segundo_Parcial.Models;

namespace Evaluación_Practica_Segundo_Parcial.Data.Ef
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Personaje> Personajes { get; set; }
    }
}
