﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Evaluación_Practica_Segundo_Parcial.Models;  // Ajusta el namespace si es necesario

namespace Evaluación_Practica_Segundo_Parcial.Data.Ef
{
    public class EfPersonaje
    {
        private readonly AppDbContext _context;

        public EfPersonaje(AppDbContext context)
        {
            _context = context;
        }

        public async Task InsertarPersonajeAsync(Personaje personaje)
        {
            _context.Personajes.Add(personaje);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Personaje>> ObtenerPersonajesAsync()
        {
            return await _context.Personajes.ToListAsync();
        }
    }
}
