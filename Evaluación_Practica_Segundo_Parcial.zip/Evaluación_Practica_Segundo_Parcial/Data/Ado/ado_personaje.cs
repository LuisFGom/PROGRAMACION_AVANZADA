﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Evaluación_Practica_Segundo_Parcial.Models;

namespace Evaluación_Practica_Segundo_Parcial.Data.Ado
{
    public class AdoPersonaje
    {
        private readonly string _connectionString;

        public AdoPersonaje(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void InsertarPersonaje(Personaje personaje)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Personajes (Nombre, Edad, Poder) VALUES (@Nombre, @Edad, @Poder)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Nombre", personaje.Nombre);
                    command.Parameters.AddWithValue("@Edad", personaje.Edad);
                    command.Parameters.AddWithValue("@Poder", personaje.Poder);
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<Personaje> ObtenerPersonajes()
        {
            List<Personaje> personajes = new List<Personaje>();

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = "SELECT Id, Nombre, Edad, Poder FROM Personajes";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            personajes.Add(new Personaje
                            {
                                Id = reader.GetInt32(0),
                                Nombre = reader.GetString(1),
                                Edad = reader.GetInt32(2),
                                Poder = reader.GetString(3)
                            });
                        }
                    }
                }
            }

            return personajes;
        }
    }
}
