﻿namespace Evaluación_Practica_Segundo_Parcial.Models
{
    public class Personaje
    {
        public int Id { get; set; }          // Llave primaria
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public string Poder { get; set; }
    }
}
