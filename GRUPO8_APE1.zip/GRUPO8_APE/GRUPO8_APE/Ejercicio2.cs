﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRUPO8_APE
{
    public partial class Ejercicio2 : Form
    {
        private int numEcuaciones;
        private TextBox[,] txtCoeficientes;
        private TextBox[] txtResultados;
        private Label[] lblVariables;
        private List<Label> lblEquals;
        private SistemaEcuaciones sistema;
        public Ejercicio2()
        {
            InitializeComponent();
            // Set initial state
            numEcuaciones = 3; // Default as in your UI
            lblEquals = new List<Label>();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Nothing to do
        }

        private void nudNumEcuaciones_ValueChanged(object sender, EventArgs e)
        {
            // Update the number of equations when spinner changes
            numEcuaciones = Convert.ToInt32(((NumericUpDown)sender).Value);
        }

        
        
        private void LimpiarSistema()
        {
            // Remove all dynamically created controls if they exist
            if (txtCoeficientes != null)
            {
                for (int i = 0; i < txtCoeficientes.GetLength(0); i++)
                {
                    for (int j = 0; j < txtCoeficientes.GetLength(1); j++)
                    {
                        this.Controls.Remove(txtCoeficientes[i, j]);
                    }
                    this.Controls.Remove(txtResultados[i]);
                }

                // Remove variable labels
                for (int j = 0; j < lblVariables.Length; j++)
                {
                    this.Controls.Remove(lblVariables[j]);
                }

                // Remove equals signs
                foreach (Label lbl in lblEquals)
                {
                    this.Controls.Remove(lbl);
                }

                // Clear references
                txtCoeficientes = null;
                txtResultados = null;
                lblVariables = null;
                lblEquals.Clear();

                // Force redraw
                this.Refresh();
            }
        }


        private void Ejercicio2_Load(object sender, EventArgs e)
        {

        }

        private void BtnVolver_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCrearSistema_Click_1(object sender, EventArgs e)
        {
            // Clear any existing system first
            LimpiarSistema();

            // Create matrix input fields
            txtCoeficientes = new TextBox[numEcuaciones, numEcuaciones];
            txtResultados = new TextBox[numEcuaciones];
            lblVariables = new Label[numEcuaciones];
            lblEquals = new List<Label>();

            int startX = 50;
            int startY = 150;
            int width = 40;
            int height = 25;
            int spacing = 50;

            // Create input fields for coefficients and results
            for (int i = 0; i < numEcuaciones; i++)
            {
                for (int j = 0; j < numEcuaciones; j++)
                {
                    txtCoeficientes[i, j] = new TextBox();
                    txtCoeficientes[i, j].Location = new Point(startX + j * spacing, startY + i * spacing);
                    txtCoeficientes[i, j].Size = new Size(width, height);
                    txtCoeficientes[i, j].Text = "0";
                    this.Controls.Add(txtCoeficientes[i, j]);

                    // Add variable labels for the first row
                    if (i == 0)
                    {
                        lblVariables[j] = new Label();
                        lblVariables[j].Location = new Point(startX + j * spacing, startY - 25);
                        lblVariables[j].Size = new Size(width, height);
                        lblVariables[j].Text = $"x{j + 1}";
                        lblVariables[j].TextAlign = ContentAlignment.MiddleCenter;
                        this.Controls.Add(lblVariables[j]);
                    }
                }

                // Add equals sign
                Label lblEqual = new Label();
                lblEqual.Location = new Point(startX + numEcuaciones * spacing, startY + i * spacing);
                lblEqual.Size = new Size(20, height);
                lblEqual.Text = "=";
                lblEqual.TextAlign = ContentAlignment.MiddleCenter;
                this.Controls.Add(lblEqual);
                lblEquals.Add(lblEqual);

                // Add result input
                txtResultados[i] = new TextBox();
                txtResultados[i].Location = new Point(startX + (numEcuaciones + 1) * spacing, startY + i * spacing);
                txtResultados[i].Size = new Size(width, height);
                txtResultados[i].Text = "0";
                this.Controls.Add(txtResultados[i]);
            }
        }

        private void btnResolverSistema_Click_1(object sender, EventArgs e)
        {
            if (txtCoeficientes == null || txtResultados == null)
            {
                MessageBox.Show("Primero debe crear el sistema de ecuaciones.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Create system instance
                sistema = new SistemaEcuaciones(numEcuaciones);

                // Fill with data from inputs
                for (int i = 0; i < numEcuaciones; i++)
                {
                    for (int j = 0; j < numEcuaciones; j++)
                    {
                        double valor = Convert.ToDouble(txtCoeficientes[i, j].Text);
                        sistema.SetCoeficiente(i, j, valor);
                    }
                    double resultado = Convert.ToDouble(txtResultados[i].Text);
                    sistema.SetResultado(i, resultado);
                }

                // Solve the system
                string solucion = sistema.Resolver();

                // Display solution
                MessageBox.Show(solucion, "Solución del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese solo valores numéricos.", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al resolver el sistema: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click_1(object sender, EventArgs e)
        {
            LimpiarSistema();
        }
    }
}
