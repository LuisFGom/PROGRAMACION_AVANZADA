﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRUPO8_APE
{
    public partial class Ejercicio3 : Form
    {
        public Ejercicio3()
        {
            InitializeComponent();
        }

        private double[,] ObtenerMatriz(DataGridView dgv)
        {
            int Filas = dgv.RowCount;
            int Columnas = dgv.ColumnCount;
            if (Filas == 0 || Columnas == 0) return null;

            double[,] matriz = new double[Filas, Columnas];
            for (int i = 0; i < Filas; i++)
            {
                for (int j = 0; j < Columnas; j++)
                {
                    if (double.TryParse(dgv[j, i].Value?.ToString(), out double value))
                    {
                        matriz[i, j] = value;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            return matriz;
        }

        private void MostrarMatriz(double[,] matriz, DataGridView dgv)
        {
            dgv.AllowUserToAddRows = false;
            dgv.RowHeadersVisible = false;
            dgv.ColumnHeadersVisible = false;
            dgv.ScrollBars = ScrollBars.None;
            dgv.AllowUserToResizeColumns = false;
            dgv.AllowUserToResizeRows = false;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            int Filas = matriz.GetLength(0);
            int Columnas = matriz.GetLength(1);
            dgv.ColumnCount = Columnas;
            dgv.RowCount = Filas;

            for (int i = 0; i < Filas; i++)
            {
                for (int j = 0; j < Columnas; j++)
                {
                    dgv[j, i].Value = matriz[i, j].ToString("F3");
                }
            }
        }

        private (double[,], double[,]) AlgoritmoGramSchmidtQR(double[,] A)
        {
            int Filas = A.GetLength(0);
            int Columnas = A.GetLength(1);
            double[,] Q = new double[Filas, Columnas];
            double[,] R = new double[Columnas, Columnas];

            for (int k = 0; k < Columnas; k++)
            {
                double[] v = Enumerable.Range(0, Filas).Select(i => A[i, k]).ToArray();

                for (int j = 0; j < k; j++)
                {
                    double dot = v.Zip(Enumerable.Range(0, Filas).Select(i => Q[i, j]), (vi, qj) => vi * qj).Sum();
                    R[j, k] = dot;
                    v = v.Zip(Enumerable.Range(0, Filas).Select(i => Q[i, j]), (vi, qj) => vi - dot * qj).ToArray();
                }
                R[k, k] = Math.Sqrt(v.Sum(vi => vi * vi));
                for (int i = 0; i < Filas; i++) Q[i, k] = v[i] / R[k, k];
            }
            return (Q, R);
        }

        private bool EsOrtogonal(double[,] Q)
        {
            int Columnas = Q.GetLength(1);
            for (int i = 0; i < Columnas; i++)
            {
                for (int j = i + 1; j < Columnas; j++)
                {
                    double dot = Enumerable.Range(0, Q.GetLength(0)).Sum(k => Q[k, i] * Q[k, j]);
                    if (Math.Abs(dot) > 1e-6) return false;
                }
            }
            return true;
        }

        private void Ejer3_Load(object sender, EventArgs e)
        {

        }

        private void btnGenerar_Click_1(object sender, EventArgs e)
        {
            dgvMatriz1.AllowUserToAddRows = false;
            dgvMatriz1.RowHeadersVisible = false;
            dgvMatriz1.ColumnHeadersVisible = false;
            dgvMatriz1.ScrollBars = ScrollBars.None;
            dgvMatriz1.AllowUserToResizeColumns = false;
            dgvMatriz1.AllowUserToResizeRows = false;
            dgvMatriz1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvMatriz1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            if (int.TryParse(txtFilas.Text, out int Filas) && int.TryParse(txtColumnas.Text, out int Columnas))
            {
                dgvMatriz1.ColumnCount = Columnas;
                dgvMatriz1.RowCount = Filas;
            }
            else
            {
                MessageBox.Show("Ingrese valores válidos para M y N");
            }
        }

        private void btnCalcular_Click_1(object sender, EventArgs e)
        {
            double[,] matriz = ObtenerMatriz(dgvMatriz1);
            if (matriz == null) return;

            var (Q, R) = AlgoritmoGramSchmidtQR(matriz);
            MostrarMatriz(Q, dgvMatrizQ);
            MostrarMatriz(R, dgvMatrizR);
        }

        private void btnVerificar_Click_1(object sender, EventArgs e)
        {
            double[,] Q = ObtenerMatriz(dgvMatrizQ);
            if (Q == null)
            {
                MessageBox.Show("Debe calcular primero la matriz Q.");
                return;
            }
            lblResultado.Text = EsOrtogonal(Q) ? "La matriz Q es ortogonal." : "La matriz Q no es ortogonal.";

        }

        private void LimpiarMatriz(DataGridView dgv)
        {
            foreach (DataGridViewRow row in dgv.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    cell.Value = "";
                }
            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarMatriz(dgvMatriz1);
            LimpiarMatriz(dgvMatrizQ);
            LimpiarMatriz(dgvMatrizR);
        }
    }
}
