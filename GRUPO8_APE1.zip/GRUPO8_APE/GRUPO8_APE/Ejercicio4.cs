﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRUPO8_APE
{
    public partial class Ejercicio4 : Form
    {
        public Ejercicio4()
        {
            InitializeComponent();
        }

        private double[,] ObtenerMatrizDesdeDGV(DataGridView dgv)
        {

            int filas = dgv.RowCount;
            int columnas = dgv.ColumnCount;
            Console.WriteLine("Filas: " + filas);
            Console.WriteLine("Columnas: " + columnas);
            if (filas != columnas)
            {
                MessageBox.Show("La matriz debe ser cuadrada (mismo número de filas y columnas).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            double[,] matriz = new double[filas, columnas];
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (double.TryParse(dgv.Rows[i].Cells[j].Value?.ToString(), out double valor))
                    {
                        matriz[i, j] = valor;
                    }
                    else
                    {
                        MessageBox.Show($"El valor en la posición [{i}, {j}] no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                }
            }

            return matriz;
        }

        private void MetodoJacobi(double[,] A, int n)
        {
            double[] D = new double[n];
            double[,] R = new double[n, n];

            for (int i = 0; i < n; i++)
                R[i, i] = 1;

            int maxIteraciones = 100;
            double tol = 1e-9;

            for (int iter = 0; iter < maxIteraciones; iter++)
            {
                double max = 0;
                int p = 0, q = 0;
                for (int i = 0; i < n; i++)
                {
                    for (int j = i + 1; j < n; j++)
                    {
                        if (Math.Abs(A[i, j]) > max)
                        {
                            max = Math.Abs(A[i, j]);
                            p = i;
                            q = j;
                        }
                    }
                }

                if (max < tol)
                    break;

                double theta = 0.5 * Math.Atan2(2 * A[p, q], A[q, q] - A[p, p]);
                double c = Math.Cos(theta);
                double s = Math.Sin(theta);

                double App = c * c * A[p, p] - 2 * s * c * A[p, q] + s * s * A[q, q];
                double Aqq = s * s * A[p, p] + 2 * s * c * A[p, q] + c * c * A[q, q];

                A[p, p] = App;
                A[q, q] = Aqq;
                A[p, q] = 0;
                A[q, p] = 0;

                for (int i = 0; i < n; i++)
                {
                    if (i != p && i != q)
                    {
                        double Aip = A[i, p];
                        double Aiq = A[i, q];

                        A[i, p] = c * Aip - s * Aiq;
                        A[p, i] = A[i, p];

                        A[i, q] = c * Aiq + s * Aip;
                        A[q, i] = A[i, q];
                    }
                }
            }

            for (int i = 0; i < n; i++)
                D[i] = A[i, i];
            lstAutovalores.Items.Clear();
            for (int i = 0; i < n; i++)
            {
                lstAutovalores.Items.Add($"Autovalor {i + 1}: {Math.Round(D[i], 4)}");
            }
        }
        private void Ejercicio4_Load(object sender, EventArgs e)
        {
            
        }

        private void LimpiarMatriz(DataGridView dgv)
        {
            foreach (DataGridViewRow row in dgv.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    cell.Value = "";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LimpiarMatriz(dgvMatriz);
            lstAutovalores.Items.Clear ();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGenerarMatriz_Click_1(object sender, EventArgs e)
        {
            dgvMatriz.AllowUserToAddRows = false;
            dgvMatriz.RowHeadersVisible = false;
            dgvMatriz.ColumnHeadersVisible = false;
            dgvMatriz.ScrollBars = ScrollBars.None;
            dgvMatriz.AllowUserToResizeColumns = false;
            dgvMatriz.AllowUserToResizeRows = false;
            dgvMatriz.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvMatriz.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            try
            {
                int tamaño = int.Parse(txtTamaño.Text);

                if (tamaño <= 0)
                {
                    MessageBox.Show("El tamaño de la matriz debe ser mayor que 0", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                dgvMatriz.SuspendLayout();
                dgvMatriz.Rows.Clear();
                dgvMatriz.Columns.Clear();

                // Crear columnas
                for (int i = 0; i < tamaño; i++)
                {
                    dgvMatriz.Columns.Add(new DataGridViewTextBoxColumn());
                }

                // Crear filas
                dgvMatriz.Rows.Add(tamaño);

                // Configurar ancho de columnas
                dgvMatriz.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                // Calcular altura de filas
                int espacioVerticalDisponible = dgvMatriz.ClientSize.Height - (tamaño - 1); // Restar divisores
                int alturaFila = espacioVerticalDisponible / tamaño;
                alturaFila = Math.Max(alturaFila, 20); // Altura mínima

                // Aplicar altura a todas las filas
                foreach (DataGridViewRow fila in dgvMatriz.Rows)
                {
                    fila.Height = alturaFila;
                }

                // Ajustar última fila para ocupar espacio restante
                int alturaTotalCalculada = (alturaFila * tamaño) + (tamaño - 1);
                if (alturaTotalCalculada < dgvMatriz.ClientSize.Height)
                {
                    int diferencia = dgvMatriz.ClientSize.Height - alturaTotalCalculada;
                    dgvMatriz.Rows[tamaño - 1].Height += diferencia;
                }

                // Ajustar tamaño de celdas
                foreach (DataGridViewColumn columna in dgvMatriz.Columns)
                {
                    columna.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }

                dgvMatriz.ResumeLayout();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double[,] matriz = ObtenerMatrizDesdeDGV(dgvMatriz);
            if (matriz != null)
            {
                int tamaño = matriz.GetLength(0);
                MetodoJacobi(matriz, tamaño);
            }
        }
    }
}
