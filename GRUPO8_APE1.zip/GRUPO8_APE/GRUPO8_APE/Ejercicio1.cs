﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRUPO8_APE
{
    public partial class Ejercicio1 : Form
    {
        public Ejercicio1()
        {
            InitializeComponent();
            InitializeControls();

        }
        private void InitializeControls()
        {
            // Configuración inicial del NumericUpDown
            nudSize.Minimum = 2;
            nudSize.Maximum = 20;
            nudSize.Value = 2;
            nudSize.ValueChanged += NudSize_ValueChanged;

            // Configuración inicial de los DataGridViews
            SetupDataGridView(dgvMatrixA, 2);
            SetupDataGridView(dgvMatrixB, 2);
            SetupDataGridView(dgvResultado, 2);
            dgvResultado.ReadOnly = true;

            // Configuración del botón
            btnMultiplicar.Click += BtnMultiply_Click;
        }


        private void SetupDataGridView(DataGridView dgv, int n)
        {
            dgv.AllowUserToAddRows = false;
            dgv.RowHeadersVisible = false;
            dgv.ColumnHeadersVisible = false;
            dgv.ScrollBars = ScrollBars.None;
            dgv.AllowUserToResizeColumns = false;
            dgv.AllowUserToResizeRows = false;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgv.Columns.Clear();
            dgv.Rows.Clear();
            // Calcular el ancho de las columnas basado en el ancho total del DataGridView
            int columnWidth = dgv.Width / n;

            // Agregar columnas
            for (int i = 0; i < n; i++)
            {
                dgv.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    Width = columnWidth,
                    HeaderText = ""
                });
            }

            // Agregar filas
            for (int i = 0; i < n; i++)
            {
                dgv.Rows.Add();
            }

            // Ajustar altura de filas basado en la altura total del DataGridView
            if (dgv.Rows.Count > 0)
            {
                int rowHeight = (dgv.Height / n) - 2;
                foreach (DataGridViewRow row in dgv.Rows)
                    row.Height = rowHeight;
            }
        }

        private void NudSize_ValueChanged(object sender, EventArgs e)
        {
            int n = (int)nudSize.Value;
            SetupDataGridView(dgvMatrixA, n);
            SetupDataGridView(dgvMatrixB, n);
            SetupDataGridView(dgvResultado, n);
        }

        private int[,] ReadMatrixFromDataGridView(DataGridView dgv, int n)
        {
            int[,] matrix = new int[n, n];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    var cell = dgv.Rows[i].Cells[j].Value;
                    if (cell == null)
                        throw new FormatException($"Celda [{i + 1},{j + 1}] está vacía.");
                    if (!int.TryParse(cell.ToString(), out matrix[i, j]))
                        throw new FormatException($"Valor inválido en la celda [{i + 1},{j + 1}].");
                }
            }
            return matrix;
        }

        private int[,] MultiplyMatrices(int[,] a, int[,] b)
        {
            int n = a.GetLength(0);
            int[,] result = new int[n, n];

            Parallel.For(0, n, i =>
            {
                for (int j = 0; j < n; j++)
                {
                    int sum = 0;
                    for (int k = 0; k < n; k++)
                    {
                        sum += a[i, k] * b[k, j];
                    }
                    result[i, j] = sum;
                }
            });

            return result;
        }

        private void DisplayMatrix(DataGridView dgv, int[,] matrix)
        {
            int n = matrix.GetLength(0);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    dgv.Rows[i].Cells[j].Value = matrix[i, j];
                }
            }
        }

        private void BtnMultiply_Click(object sender, EventArgs e)
        {
            try
            {
                int n = (int)nudSize.Value;

                var matrixA = ReadMatrixFromDataGridView(dgvMatrixA, n);
                var matrixB = ReadMatrixFromDataGridView(dgvMatrixB, n);

                if (matrixA.GetLength(1) != matrixB.GetLength(0))
                    throw new InvalidOperationException("Matrices incompatibles: Columnas de la primera deben ser igual a filas de la segunda");

                var result = MultiplyMatrices(matrixA, matrixB);
                DisplayMatrix(dgvResultado, result);
            }
            catch (FormatException ex)
            {
                MessageBox.Show($"Error de formato: {ex.Message}", "Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message, "Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error inesperado: {ex.Message}", "Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Menu_FormClosed(object sender, FormClosedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void LimpiarMatriz(DataGridView dgv)
        {
            foreach (DataGridViewRow row in dgv.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    cell.Value = "";
                }
            }
        }
        private void Menu_Load(object sender, EventArgs e)
        {
            
        }

        private void btnMultiply_Click_1(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarMatriz(dgvMatrixA);
            LimpiarMatriz(dgvMatrixB);
            LimpiarMatriz(dgvResultado);
        }
    }
}
