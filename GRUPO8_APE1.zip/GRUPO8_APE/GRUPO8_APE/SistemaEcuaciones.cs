﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRUPO8_APE
{
    public class SistemaEcuaciones
    {
        private double[,] matriz;
        private double[] resultados;
        private int n; // Number of equations/unknowns

        public SistemaEcuaciones(int n)
        {
            this.n = n;
            matriz = new double[n, n];
            resultados = new double[n];
        }

        // Set coefficient value in matrix
        public void SetCoeficiente(int fila, int columna, double valor)
        {
            matriz[fila, columna] = valor;
        }

        // Set result value
        public void SetResultado(int fila, double valor)
        {
            resultados[fila] = valor;
        }

        // Apply Gaussian elimination to solve the system
        public string Resolver()
        {
            // Create augmented matrix [A|b]
            double[,] aumentada = new double[n, n + 1];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    aumentada[i, j] = matriz[i, j];
                }
                aumentada[i, n] = resultados[i];
            }

            // Forward elimination
            for (int k = 0; k < n; k++)
            {
                // Find pivot
                int maxRow = k;
                double maxVal = Math.Abs(aumentada[k, k]);
                for (int i = k + 1; i < n; i++)
                {
                    if (Math.Abs(aumentada[i, k]) > maxVal)
                    {
                        maxVal = Math.Abs(aumentada[i, k]);
                        maxRow = i;
                    }
                }

                // Swap rows if needed
                if (maxRow != k)
                {
                    for (int j = k; j <= n; j++)
                    {
                        double temp = aumentada[k, j];
                        aumentada[k, j] = aumentada[maxRow, j];
                        aumentada[maxRow, j] = temp;
                    }
                }

                // Check for singular matrix
                if (Math.Abs(aumentada[k, k]) < 1e-10)
                {
                    // Check if this is a row of zeros with non-zero result (inconsistent)
                    bool allZeros = true;
                    for (int j = k; j < n; j++)
                    {
                        if (Math.Abs(aumentada[k, j]) >= 1e-10)
                        {
                            allZeros = false;
                            break;
                        }
                    }

                    if (allZeros && Math.Abs(aumentada[k, n]) >= 1e-10)
                        return "El sistema no tiene solución.";
                    else if (allZeros)
                        continue; // Skip this row, might have infinite solutions
                    else
                        return "El sistema tiene infinitas soluciones.";
                }

                // Eliminate below
                for (int i = k + 1; i < n; i++)
                {
                    double factor = aumentada[i, k] / aumentada[k, k];
                    for (int j = k; j <= n; j++)
                    {
                        aumentada[i, j] -= factor * aumentada[k, j];
                    }
                }
            }

            // Back substitution
            double[] soluciones = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                soluciones[i] = aumentada[i, n];
                for (int j = i + 1; j < n; j++)
                {
                    soluciones[i] -= aumentada[i, j] * soluciones[j];
                }

                // Check for zero coefficient with non-zero result
                if (Math.Abs(aumentada[i, i]) < 1e-10)
                {
                    if (Math.Abs(soluciones[i]) >= 1e-10)
                        return "El sistema no tiene solución.";
                    else
                        return "El sistema tiene infinitas soluciones.";
                }

                soluciones[i] /= aumentada[i, i];
            }

            // Format the solution
            string resultado = "Solución:\n";
            for (int i = 0; i < n; i++)
            {
                resultado += $"x{i + 1} = {Math.Round(soluciones[i], 4)}\n";
            }

            return resultado;
        }
    }
}
