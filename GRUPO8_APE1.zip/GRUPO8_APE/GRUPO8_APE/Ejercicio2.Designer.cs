﻿namespace GRUPO8_APE
{
    partial class Ejercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nudNumEcuaciones = new System.Windows.Forms.NumericUpDown();
            this.btnResolverSistema = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnVolver = new System.Windows.Forms.Button();
            this.btnCrearSistema = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumEcuaciones)).BeginInit();
            this.SuspendLayout();
            // 
            // nudNumEcuaciones
            // 
            this.nudNumEcuaciones.Location = new System.Drawing.Point(140, 11);
            this.nudNumEcuaciones.Margin = new System.Windows.Forms.Padding(2);
            this.nudNumEcuaciones.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudNumEcuaciones.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nudNumEcuaciones.Name = "nudNumEcuaciones";
            this.nudNumEcuaciones.Size = new System.Drawing.Size(90, 20);
            this.nudNumEcuaciones.TabIndex = 11;
            this.nudNumEcuaciones.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // btnResolverSistema
            // 
            this.btnResolverSistema.Location = new System.Drawing.Point(115, 407);
            this.btnResolverSistema.Margin = new System.Windows.Forms.Padding(2);
            this.btnResolverSistema.Name = "btnResolverSistema";
            this.btnResolverSistema.Size = new System.Drawing.Size(126, 32);
            this.btnResolverSistema.TabIndex = 10;
            this.btnResolverSistema.Text = "RESOLVER SISTEMA";
            this.btnResolverSistema.UseVisualStyleBackColor = true;
            this.btnResolverSistema.Click += new System.EventHandler(this.btnResolverSistema_Click_1);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(266, 407);
            this.btnLimpiar.Margin = new System.Windows.Forms.Padding(2);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(83, 32);
            this.btnLimpiar.TabIndex = 9;
            this.btnLimpiar.Text = "LIMPIAR";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Numero de Ecuaciones";
            // 
            // BtnVolver
            // 
            this.BtnVolver.Location = new System.Drawing.Point(11, 409);
            this.BtnVolver.Margin = new System.Windows.Forms.Padding(2);
            this.BtnVolver.Name = "BtnVolver";
            this.BtnVolver.Size = new System.Drawing.Size(81, 30);
            this.BtnVolver.TabIndex = 7;
            this.BtnVolver.Text = "REGRESAR";
            this.BtnVolver.UseVisualStyleBackColor = true;
            this.BtnVolver.Click += new System.EventHandler(this.BtnVolver_Click_1);
            // 
            // btnCrearSistema
            // 
            this.btnCrearSistema.Location = new System.Drawing.Point(251, 11);
            this.btnCrearSistema.Margin = new System.Windows.Forms.Padding(2);
            this.btnCrearSistema.Name = "btnCrearSistema";
            this.btnCrearSistema.Size = new System.Drawing.Size(115, 24);
            this.btnCrearSistema.TabIndex = 6;
            this.btnCrearSistema.Text = "Crear Sistema";
            this.btnCrearSistema.UseVisualStyleBackColor = true;
            this.btnCrearSistema.Click += new System.EventHandler(this.btnCrearSistema_Click_1);
            // 
            // Ejercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.nudNumEcuaciones);
            this.Controls.Add(this.btnResolverSistema);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnVolver);
            this.Controls.Add(this.btnCrearSistema);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Ejercicio2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ejercicio2";
            this.Load += new System.EventHandler(this.Ejercicio2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudNumEcuaciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nudNumEcuaciones;
        private System.Windows.Forms.Button btnResolverSistema;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnVolver;
        private System.Windows.Forms.Button btnCrearSistema;
    }
}